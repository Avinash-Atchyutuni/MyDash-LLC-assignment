from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated  # <-- Here
from django.contrib.auth.models import User
from django.http import JsonResponse
from datetime import datetime
import os,shutil
class HelloView(APIView):
    permission_classes = (IsAuthenticated, )             # <-- And here
    def get(self, request):
        p = datetime.today()
        d = p.strftime("%H:%M:%S")
        k = d.split(':')
        t=int(k[0])
        t_p = 'temp\\'+str(t)+'.txt'
        try:
            fp = open(t_p,'r+')
            attempts = int(fp.read())
            fp.close()
        except FileNotFoundError:
            try:
                shutil.rmtree('temp')
            except OSError:
                print('already deleted')
            try:
                os.mkdir('temp')
            except FileExistsError:
                print('already exists')

            
            fp = open(t_p,'w+')
            fp.write('10')
            fp.close()
            fp = open(t_p,'r+')
            attempts = int(fp.read())
            fp.close()
        if attempts!=0:
            superusers = User.objects.filter(is_superuser=True)
            superusers_emails = superusers.values_list('email')
            if len(superusers_emails[0][0])==0:
                superusers_emails = [['Sorry, I dont know your email']]
            
            superusers_username = superusers.values_list('username')
            if len(superusers_username[0][0])==0:
                superusers_username = [['Sorry, I dont know your name']]
            p = superusers_username[0][0]
            e = superusers_emails[0][0]
            content = {'message':f'Hi {p}' ,'details':{'username':p,'email':e},'attempts left for this hour':attempts-1}
            fp = open(t_p,'w+')
            attempts-=1
            fp.write(str(attempts))
            fp.close()
            return Response(content)
        else:
            return Response('Sorry you have already logged in 10 times in 1 hour')